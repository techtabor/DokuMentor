A Pen created at CodePen.io. You can find this one at https://codepen.io/dapagyi/pen/RQxMRJ.

 Simple upload UI animation  concept 